package example.springbootexam;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringbootExamApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringbootExamApplication.class, args);
	}

}
