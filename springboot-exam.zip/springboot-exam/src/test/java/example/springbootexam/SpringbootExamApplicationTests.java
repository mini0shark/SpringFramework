package example.springbootexam;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringbootExamApplicationTests {

	@Test
	void contextLoads() {
	}

}
